<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>iCircle</title>
    <link rel="stylesheet" href="css/components.css">
    <link rel="stylesheet" href="css/icons.css">
    <link rel="stylesheet" href="css/responsee.css">
    <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="owl-carousel/owl.theme.css">
    <!-- CUSTOM STYLE -->
    <link rel="stylesheet" href="css/template-style.css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.min.js"></script>    
    <script type="text/javascript" src="js/validation.js"></script> 
  </head>  
  
  <body class="size-1140">
  
    <!-- HEADER -->
    <header role="banner">    
      <!-- Top Navigation -->
      <nav class="background-white background-primary-hightlight">
        <div class="line">
          <div class="s-12 l-2">
            <a href="home.php" class="logo"><img src="img/ic.png" alt=""></a>
          </div>
          <div class="top-nav s-12 l-10">
            <p class="nav-text"></p>
            <ul class="right chevron">
              <li><a href="?menu=home">Home</a></li>
              <li><a href="?menu=profile">Profile</a></li>
              <li><a>Jawa Tengah</a>
                <ul>
                  <li><a>Kota Semarang</a>
                    <ul>
                      <li><a href="?menu=mugas">Kec. Mugassari</a></li>
                      <li><a href="?menu=gunungpati">Kec. Gunungpati</a></li>
					  <li><a href="?menu=pedurungan">Kec. Pedurungan</a></li>
					  <li><a href="?menu=tembalang">Kec. Tembalang</a></li>
					</ul>
                  </li>
				  <li><a>Kota Surakarta</a>
				    <ul>
                      <li><a href="?menu=laweyan">Kec. Laweyan</a></li>
                      <li><a href="?menu=sangkrah">Kec. Sangkrah</a></li>
					  <li><a href="?menu=serengan">Kec. Serengan</a></li>
					</ul>
				  </li>
                  <li><a>Kab. Demak</a>
				    <ul>
                      <li><a href="?menu=demak">Kec. Demak</a></li>
                      <li><a href="?menu=dempet">Kec. Dempet</a></li>
					  <li><a href="?menu=sayung">Kec. Sayung</a></li>
					</ul>
				  </li>
				  <li><a>Kab. Kudus</a>
					<ul>
						<li><a href="?menu=kudus">Kec. Kota Kudus</a></li>
						<li><a href="?menu=gebog">Kec. Gebog</a></li>
					</ul>
				  </li>
				  <li><a>Kab. Magelang</a>
					<ul>
						<li><a href="?menu=borobudur">Kec. Borobudur</a></li>
						<li><a href="?menu=grabag">Kec. Grabag</a></li>
						<li><a href="?menu=kajoran">Kec. Kajoran</a></li>
						<li><a href="?menu=kaliangkrik">Kec. Kaliangkrik</a></li>
						<li><a href="?menu=kaliangkrik">Kec. Mertoyudan</a></li>
					</ul>
				  </li>
                </ul>
				  </li>
              </li>
              <li><a>Jawa Barat</a>
			   <ul>
                  <li><a>Kab. Bandung</a>
                    <ul>
                      <li><a href="?menu=cikancung">Kec. Cikancung</a></li>
                      <li><a href="?menu=ciwidey">Kec. Ciwidey</a></li>
                    </ul>
                  </li>
                  <li><a>Kab. Sukabumi</a>
				  <ul>
                      <li><a href="?menu=cicantayan">Kec. Cicantayan</a></li>
                      <li><a href="?menu=kabandungan">Kec. Kabandungan</a></li>
					  <li><a href="?menu=surade">Kec. Surade</a></li>
					  <li><a href="?menu=cisarap">Kec. Cisarap</a></li>
                   </ul>
				  </li>
				  <li><a>Kota Bandung</a>
					<ul>
				      <li><a href="?menu=dunguscariang">Kec. Dunguscariang</a></li>
                      <li><a href="?menu=maleber">Kec. Maleber</a></li>
					  <li><a href="?menu=cijerah">Kec. Cijerah</a></li>
					  <li><a href="?menu=sukaluyu">Kec. Sukaluyu</a></li>
					</ul>
				  </li>
				  <li><a>Kota Bekasi</a>
				    <ul>
				      <li><a href="?menu=cikiwul">Kec. Cikiwul</a></li>
                      <li><a href="?menu=jatikarya">Kec. Jatikarya</a></li>
					</ul>
				  </li>
				  <li><a>Kota Depok</a>
				    <ul>
				      <li><a href="?menu=cipayung">Kec. Cipayung</a></li>
                      <li><a href="?menu=cinere">Kec. Cinere</a></li>
					  <li><a href="?menu=cimanggis">Kec. Cimanggis</a></li>
					</ul>
				  </li>
				  </ul>
			  </li>
              <li><a href="contact.html">Contact</a></li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
    
    <!-- MAIN -->
    <main role="main">
      <!-- Main Carousel -->
      <section class="section background-dark">
        <div class="line">
          <div class="carousel-fade-transition owl-carousel carousel-main carousel-nav-white carousel-wide-arrows">
            <div class="item">
              <div class="s-12 center">
                <img src="img/hujan.jpg" alt="">
              </div>
            </div>
            <div class="item">
              <div class="s-12 center">
                <img src="img/kemarau.jpg" alt="">
              </div>
            </div>
          </div>  
        </div>
      </section>
      
      <!-- Section 1 -->
      <section class="section background-white"> 
        <div class="line">
          <div class="margin" align='center'>
            <?php
				error_reporting(0);
				if($_GET[menu]=='')
					{
					include('home.php');
					}
				else
					{
					include($_GET[menu].'.php');
					}
			?>
        </div>
      </section> 
    </main>
    
    <!-- FOOTER -->
    <footer>
    <!-- Main Footer -->
      <section class="section background-dark">
        <div class="line">  
            <!-- Collumn 2 -->
            <div class="s-12 m-12 l-4 margin-m-bottom-2x">
              <h4 class="text-uppercase text-strong">Contact Us</h4>
              <div class="line">
                <div class="s-1 m-1 l-1 text-center">
                  <i class="icon-placepin text-primary text-size-12"></i>
                </div>
                <div class="s-11 m-11 l-11 margin-bottom-10">
                  <p><b>Alamat:</b> Jl.Kintelan Baru No.15 Rt 5 Rw 2</p>
                </div>
              </div>
              <div class="line">
                <div class="s-1 m-1 l-1 text-center">
                  <i class="icon-mail text-primary text-size-12"></i>
                </div>
                <div class="s-11 m-11 l-11 margin-bottom-10">
                  <p><a href="/" class="text-primary-hover"><b>E-mail:</b> <i>yossierisang@gmail.com</i></a></p>
                </div>
              </div>
              <div class="line">
                <div class="s-1 m-1 l-1 text-center">
                  <i class="icon-smartphone text-primary text-size-12"></i>
                </div>
                <div class="s-11 m-11 l-11 margin-bottom-10">
                  <p><b>Phone:</b> 089 xxx xxx xxx</p>
                </div>
              </div>
              <div class="line">
                <div class="s-1 m-1 l-1 text-center">
                  <i class="icon-twitter text-primary text-size-12"></i>
                </div>
                <div class="s-11 m-11 l-11 margin-bottom-10">
                  <p><a href="/" class="text-primary-hover"><b>Twitter :</b> <i>@yossixrisang</i></a></p>
                </div>
              </div>
              <div class="line">
                <div class="s-1 m-1 l-1 text-center">
                  <i class="icon-instagram text-primary text-size-12"></i>
                </div>
                <div class="s-11 m-11 l-11">
                  <p><a href="/" class="text-primary-hover"><b>Instagram :</b> <i>@yossierisang</i></a></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <hr class="break margin-top-bottom-0" style="border-color: rgba(0, 38, 51, 0.80);">
      
      <!-- Bottom Footer -->
      <section class="padding background-dark">
        <div class="line">
          <div class="s-12 l-6">
            <p class="text-size-12"><i>Copyright 2017, Yossie Risang Adi P</i></p>
          </div>
        </div>
      </section>
    </footer>
    <script type="text/javascript" src="js/responsee.js"></script>
    <script type="text/javascript" src="owl-carousel/owl.carousel.js"></script>
    <script type="text/javascript" src="js/template-scripts.js"></script>   
   </body>
</html>