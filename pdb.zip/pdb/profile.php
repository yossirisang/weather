<div align='center'>
Nim : 14.01.55.0042<br>
Nama : Yossie Risang Adi P
</div>